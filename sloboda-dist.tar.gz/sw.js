/*
 * Минимальный service worker демо «Смоленская Слобода».
 * Статика — cache-first, переходы по страницам — network-first с откатом в кеш.
 * Ни push, ни фоновой синхронизации: приложение офлайновое и без бэкенда.
 *
 * Приложение живёт в подпапке /sloboda/, поэтому все пути считаются от BASE,
 * а не от корня домена: на smolenka75.ru рядом стоит другой сайт, и лезть
 * за его пределы воркер не должен.
 *
 * Имя кеша версионируется: поменяли VERSION — старый кеш удаляется в activate.
 */
const VERSION = 'v2';
const BASE = '/sloboda/';
const CACHE = `sloboda-${VERSION}`;
// Кладём в кеш только то, что точно есть у любой сборки.
const PRECACHE = [
  BASE,
  `${BASE}manifest.webmanifest`,
  `${BASE}icons/icon-192.png`,
  `${BASE}icons/icon-512.png`,
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      // Отдельные файлы могут не найтись (например, при смене имён бандла) —
      // это не повод валить установку целиком.
      .then((cache) => Promise.allSettled(PRECACHE.map((url) => cache.add(url))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  // Чужие домены и соседние разделы сайта не трогаем совсем.
  if (url.origin !== self.location.origin) return;
  if (!url.pathname.startsWith(BASE)) return;

  // Переходы по страницам: сначала сеть, офлайн — из кеша.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(request, copy));
          return response;
        })
        .catch(() => caches.match(request).then((cached) => cached || caches.match(BASE)))
    );
    return;
  }

  // Статика: сначала кеш, потом сеть.
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.ok && response.type === 'basic') {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(request, copy));
        }
        return response;
      });
    })
  );
});
